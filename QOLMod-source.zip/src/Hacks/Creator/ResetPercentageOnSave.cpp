#include "../../Client/Module.hpp"
#include <Geode/modify/EditorPauseLayer.hpp>

using namespace geode::prelude;

class ResetPercentageOnSave : public Module
{
    public:
        MODULE_SETUP(ResetPercentageOnSave)
        {
            setID("reset-percentage-on-save");
            setCategory("Creator");
        }
};

SUBMIT_HACK(ResetPercentageOnSave);

// NOTE 2.2091: EditorPauseLayer::saveLevel is inline on Windows (not hookable)
#ifndef GEODE_IS_WINDOWS
class $modify (EditorPauseLayer)
{
    void saveLevel()
    {
        if (ResetPercentageOnSave::get()->getRealEnabled())
        {
            if (LevelEditorLayer::get()->m_level->m_levelType == GJLevelType::Editor)
                LevelEditorLayer::get()->m_level->m_normalPercent = 0;
        }

        EditorPauseLayer::saveLevel();
    }
};
#endif
