#include "../../Client/Module.hpp"
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/CCSpriteGrayscale.hpp>
#include <Geode/modify/CreatorLayer.hpp>

using namespace geode::prelude;

class UnlockButtons : public Module
{
    public:
        MODULE_SETUP(UnlockButtons)
        {
            setName("Unlock Buttons");
            setID("unlock-buttons");
            setCategory("Cosmetic");
            setDescription("Visually Unlocks the greyed out buttons in the online page");
        }
};

SUBMIT_HACK(UnlockButtons);

bool __creatorlayer__init__ = false;

class $modify(CCSpriteGrayscale)
{
    // NOTE 2.2091: bindings have no iOS addresses for CCSpriteGrayscale; hook disabled on iOS
    #ifndef GEODE_IS_IOS

    static CCSpriteGrayscale* createWithSpriteFrameName(std::string const& spr)
    {
        auto res = CCSpriteGrayscale::createWithSpriteFrameName(spr);

        if (!__creatorlayer__init__ || !UnlockButtons::get()->getRealEnabled())
            return res;

        auto spr2 = CCSprite::createWithSpriteFrameName(spr.c_str());
        spr2->setPosition(res->getContentSize() / 2);

        res->addChild(spr2);
        res->setOpacity(0);
        
        return res;
    }

    #endif
};

class $modify (CreatorLayer)
{
    virtual bool init()
    {
        __creatorlayer__init__ = true;

        auto ret = CreatorLayer::init();

        __creatorlayer__init__ = false;

        return ret;
    }
};