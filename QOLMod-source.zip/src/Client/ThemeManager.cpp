#include <asp/fs.hpp>
#include "ThemeManager.hpp"
#include <Geode/Geode.hpp>

using namespace geode::prelude;
using namespace qolmod;

ThemeManager* ThemeManager::get()
{
    static ThemeManager* instance = []{
        auto pRet = new ThemeManager();
        pRet->load();
        return pRet;
    }();

    return instance;
}

void ThemeManager::save()
{
    Mod::get()->setSavedValue<int>("theme", (int)background);
}

void ThemeManager::load()
{
    background = (BackgroundType)Mod::get()->getSavedValue<int>("theme", (int)background);

    if (!asp::fs::exists(Mod::get()->getConfigDir() / "ui-background.png"))
    {
        auto path = Mod::get()->getSavedValue<std::string>("custom-background-path", "");

        if (!path.empty())
        {
            (void)asp::fs::copy(
                asp::fs::Path(Mod::get()->getSavedValue<std::string>("custom-background-path", "")),
                Mod::get()->getConfigDir() / "ui-background.png"
            );

            Mod::get()->setSavedValue<std::string>("custom-background-path", "");
        }
    }
}

MenuAnimation ThemeManager::getAnimation()
{
    return anim;
}

void ThemeManager::setAnimation(MenuAnimation animation)
{
    this->anim = animation;
    save();
}

BackgroundType ThemeManager::getBackground()
{
    return background;
}

void ThemeManager::setBackground(BackgroundType background)
{
    this->background = background;
    save();
}

void ThemeManager::setCustomSprite(asp::fs::Path path)
{
    CCTextureCache::get()->removeTextureForKey((Mod::get()->getConfigDir() / "ui-background.png").string().c_str());
    if (path.empty() || !asp::fs::exists(path))
    {
        (void)asp::fs::remove(Mod::get()->getConfigDir() / "ui-background.png");
        return;
    }

    (void)asp::fs::copy(path, Mod::get()->getConfigDir() / "ui-background.png");
}

CCSprite* ThemeManager::createCustomSprite(bool returnDefault)
{
    auto path = (Mod::get()->getConfigDir() / "ui-background.png").string();
    CCSprite* spr = nullptr;

    if (CCFileUtils::get()->isFileExist(path.c_str()))
        spr = CCSprite::create(path.c_str());

    if (spr)
    {
        if (spr->getUserObject("geode.texture-loader/fallback"))
            spr = nullptr;

        #if GEODE_COMP_GD_VERSION >= 22081
        if (spr && spr->isUsingFallback())
            spr = nullptr;
        #endif
    }

    if (!spr && returnDefault)
        spr = CCSprite::create("sog.png"_spr);

    return spr;
}