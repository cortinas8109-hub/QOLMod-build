#pragma once

#include "CategoryNode.hpp"
#include "../GUI/CategoryTabSprite.hpp"
#include <Button.hpp>

class SubCategoryNode : public CategoryNode
{
    protected:
        CCMenu* selectSubMenu = nullptr;
        std::unordered_map<std::string, CategoryTabSprite*> normalSprs = {};
        std::unordered_map<std::string, qolmod::Button*> normalBtns = {};
        std::unordered_map<qolmod::Button*, bool> categoryBtnsSelCheck = {};
        std::unordered_map<std::string, CategoryNode*> categoryNodes = {};
        static inline std::unordered_map<std::string, std::string> selectedSub = {};
    
    public:
        CREATE_FUNC(SubCategoryNode);
        
        void onSelectSub(CCObject* sender);
        void addModule(Module* mod, std::string subCategory);

        void addSubCategory(std::string name);
        virtual void updateUI();

        bool init();
        virtual void update(float dt);
};