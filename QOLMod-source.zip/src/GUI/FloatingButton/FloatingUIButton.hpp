#pragma once

#include <Geode/Geode.hpp>
#include <Touch.hpp>

struct FloatingUIButtonVisibility
{
    bool showInMenu = true;
    bool showInGame = true;
    bool showInPauseMenu = true;
    bool showInEditor = true;
    bool showInEditorPauseMenu = true;

    bool shouldShow();
};

enum class FloatingButtonAnimationType
{
    Shrink = 0,
    GD = 1,
};

class FloatingUIButton : public cocos2d::CCNode
{
    protected:
        float scale = 0.8f;
        float opacity = 0.8f;
        bool movable = true;
        FloatingUIButtonVisibility visibilityConf = {};
        bool backgroundUsesSpriteSheet = false;
        bool overlayUsesSpriteSheet = false;

        std::function<void()> onClick = nullptr;
        std::string background = "";
        std::string overlay = "";
        cocos2d::CCSprite* overlaySpr = nullptr;
        bool isMoving = false;
        float _opacity = 0.8f;
        cocos2d::CCPoint position = cocos2d::CCPointZero;
        bool isSelected = false;
        FloatingButtonAnimationType animation = FloatingButtonAnimationType::Shrink;

        virtual void update(float dt);
        ~FloatingUIButton();

        void animate(bool release, bool clicked = false);

        virtual void setupChildren();

    public:
        static FloatingUIButton* create(std::function<void()> onClick);

        bool init();

        void setOnClick(std::function<void()> onClick);
        void setButtonVisibilityConfig(FloatingUIButtonVisibility conf);
        void setMovable(bool movable);
        void setBaseScale(float scale);
        void setBaseOpacity(float opacity);
        void setAnimation(FloatingButtonAnimationType anim);

        void updateSprites(std::string background, std::string overlay, bool backgroundSpriteSheet, bool overlaySpriteSheet);
        void updateSprites();

        virtual void updatePosition(cocos2d::CCPoint point);

        virtual bool ccTouchBegan(qolmod::Touch* touch);
        virtual void ccTouchMoved(qolmod::Touch* touch);
        virtual void ccTouchEnded(qolmod::Touch* touch);
};