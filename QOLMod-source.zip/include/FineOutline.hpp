#pragma once

#include <Geode/loader/Event.hpp>
#include <Geode/loader/Dispatch.hpp>
#include <Geode/loader/EventExport.hpp>
#include <Geode/binding/PlayerObject.hpp>
#include <Geode/binding/SimplePlayer.hpp>
#include <ccTypes.h>

namespace alpha::fine_outline {
    enum class PlayerIcon {
        SELECTED = -1,
        ONE,
        TWO
    };
}

#define MY_MOD_ID "alphalaneous.fine_outline"

namespace alpha::fine_outline {

    namespace internal {
        GEODE_EVENT_EXPORT(void, _setOutlineColorPlayerObject, (PlayerObject* player, const cocos2d::ccColor3B& color), (player, color));

        GEODE_EVENT_EXPORT(cocos2d::ccColor3B, _getOutlineColorPlayerObject, (PlayerObject* player), (player));

        GEODE_EVENT_EXPORT(void, _updateOutlinePlayerObject, (PlayerObject* player), (player));

        GEODE_EVENT_EXPORT(void, _setOutlineColorSimplePlayer, (SimplePlayer* player, const cocos2d::ccColor3B& color), (player, color));
        
        GEODE_EVENT_EXPORT(cocos2d::ccColor3B, _getOutlineColorSimplePlayer, (SimplePlayer* player), (player));

        GEODE_EVENT_EXPORT(void, _updateOutlineSimplePlayer, (SimplePlayer* player), (player));
    }

    template<class T>
    concept PlayerType =
        std::derived_from<T, PlayerObject> ||
        std::derived_from<T, SimplePlayer>;

    /// Set the outline color of a PlayerObject or SimplePlayer
    template<PlayerType T>
    inline void setOutlineColor(T* player, const cocos2d::ccColor3B& color) {
        if constexpr (std::is_base_of_v<PlayerObject, T>) {
            internal::_setOutlineColorPlayerObject(player, color);
        }
        else if constexpr (std::is_base_of_v<SimplePlayer, T>) {
            internal::_setOutlineColorSimplePlayer(player, color);
        }
    }

    /// Get the outline color of a PlayerObject or SimplePlayer
    template<PlayerType T>
    inline cocos2d::ccColor3B getOutlineColor(T* player) {
        if constexpr (std::is_base_of_v<PlayerObject, T>) {
            return internal::_getOutlineColorPlayerObject(player);
        }
        else if constexpr (std::is_base_of_v<SimplePlayer, T>) {
            return internal::_getOutlineColorSimplePlayer(player);
        }
    }

    /// Update the outline color of a PlayerObject or SimplePlayer
    /// This is useful if something else changed it for some reason
    template<PlayerType T>
    inline void updateOutline(T* player) {
        if constexpr (std::is_base_of_v<PlayerObject, T>) {
            internal::_updateOutlinePlayerObject(player);
        }
        else if constexpr (std::is_base_of_v<SimplePlayer, T>) {
            internal::_updateOutlineSimplePlayer(player);
        }
    }

    /// Check if the 2 player icons are separate with the "Separate Dual Icons" mod
    GEODE_EVENT_EXPORT(bool, isSeparate, (), ());

    /// Check if the second player is being edited in the Garage with the "Separate Dual Icons" mod
    GEODE_EVENT_EXPORT(bool, isEditingP2, (), ());

    /// Returns true if the player icon type is using a custom color rather than a color index
    /// By default, it gets the selected icon's color if Separate dual icons is installed
    GEODE_EVENT_EXPORT(bool, usesCustomColor, (alpha::fine_outline::PlayerIcon player = alpha::fine_outline::PlayerIcon::SELECTED), (player));

    /// Set if the player icon type is using a custom color rather than a color index
    GEODE_EVENT_EXPORT(void, useCustomColor, (alpha::fine_outline::PlayerIcon player, bool use), (player, use));

    /// Returns the custom color set for a player icon type
    /// By default, it gets the selected icon's color if Separate dual icons is installed
    GEODE_EVENT_EXPORT(cocos2d::ccColor3B, getCustomColor, (alpha::fine_outline::PlayerIcon player = alpha::fine_outline::PlayerIcon::SELECTED), (player));

    /// Sets the custom color for a player icon type
    GEODE_EVENT_EXPORT(void, setCustomColor, (alpha::fine_outline::PlayerIcon player, const cocos2d::ccColor3B& color), (player, color));

    /// Gets the color index for a player icon type
    /// By default, it gets the selected icon's color if Separate dual icons is installed
    GEODE_EVENT_EXPORT(int, getColorIndex, (alpha::fine_outline::PlayerIcon player = alpha::fine_outline::PlayerIcon::SELECTED), (player));

    /// Sets the color index for a player icon type
    GEODE_EVENT_EXPORT(void, setColorIndex, (alpha::fine_outline::PlayerIcon player, int color), (player, color));

    /// Gets the color for a player icon type (returns the custom one if custom, else returns the color for color index)
    /// By default, it gets the selected icon's color if Separate dual icons is installed
    GEODE_EVENT_EXPORT(cocos2d::ccColor3B, getColor, (alpha::fine_outline::PlayerIcon player = alpha::fine_outline::PlayerIcon::SELECTED), (player));
}